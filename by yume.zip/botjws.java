package com.zerox.rat.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import com.zerox.rat.service.ZEROZXService;

public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "ZEROZX_Boot";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "Boot received: " + intent.getAction());
        
        Intent serviceIntent = new Intent(context, ZEROZXService.class);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent);
        } else {
            context.startService(serviceIntent);
        }
    }
}